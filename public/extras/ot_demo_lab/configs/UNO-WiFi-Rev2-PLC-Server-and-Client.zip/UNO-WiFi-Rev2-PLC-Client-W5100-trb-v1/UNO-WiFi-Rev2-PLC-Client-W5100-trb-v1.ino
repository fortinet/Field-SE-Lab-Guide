/*
  Modbus TCP client demo for the Arduino UNO WiFi Rev2 (ATmega4809) with a W5100 Ethernet shield.

  Port of the ESP32-S3-ETH sketch. Same behaviour: every command is an FC 05 Write Single Coil
  followed by an FC 01 Read Coils read-back, each TCP session is torn down when it finishes,
  and a web page shows the lamps, per-coil read/write counts and the exact frames.

  Board:      Arduino UNO WiFi Rev2 ("Arduino megaAVR Boards" core)
              Tools > Registers emulation: None (ATMEGA4809)
  Library:    Ethernet (Arduino), included with the IDE or from the Library Manager
  Shield:     W5100 Ethernet shield (chip select D10, SD card chip select D4)
  Wi-Fi:      the on-board NINA module is not used

  The web page lives in page_gz.h (gzip-compressed). To change it, edit extras/page.html and run
  extras/make_page_h.py to regenerate page_gz.h.
*/

#include <SPI.h>
#include <Ethernet.h>
#include "page_gz.h"

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------
// The W5100 shield has no MAC address of its own. This is a locally administered address;
// use the one printed on the shield's sticker instead if it has one.
byte mac[] = { 0x02, 0x00, 0x00, 0x01, 0x01, 0x78 };

IPAddress local_IP(192, 168, 1, 20);
IPAddress gateway(192, 168, 1, 1);
IPAddress subnet(255, 255, 255, 0);
IPAddress primaryDNS(8, 8, 8, 8);

// Target Modbus server
IPAddress slave_IP(192, 168, 1, 10);
const uint16_t MODBUS_PORT    = 502;
const uint8_t  MODBUS_UNIT_ID = 255;

const uint16_t target_RED_Coil   = 0x00;
const uint16_t target_GREEN_Coil = 0x01;
const uint16_t target_BLUE_Coil  = 0x02;

// Timing
const unsigned long AUTO_INTERVAL_MS    = 1000;  // one auto-mode command per second
const uint16_t      CONNECT_TIMEOUT_MS  = 500;   // TCP connect / close limit
const unsigned long RESPONSE_TIMEOUT_MS = 500;   // wait for the server's reply

// true  = the read-back opens its own TCP session after the write session is closed, so it still
//         gets through if FortiGate ends the session when it blocks a write
// false = the read-back reuses the write's session
const bool READBACK_SEPARATE_SESSION = true;

// Hardware watchdog (about 8 s). Resets the board if the sketch ever stalls.
const bool USE_WATCHDOG = true;

// Serial debug output at 115200 baud (set to 0 to save flash)
#define DEBUG_SERIAL 1

// Shield pins
const uint8_t W5100_CS_PIN = 10;
const uint8_t SD_CS_PIN    = 4;

// ---------------------------------------------------------------------------
#if DEBUG_SERIAL
  #define DBG(x)   Serial.print(x)
  #define DBGLN(x) Serial.println(x)
#else
  #define DBG(x)
  #define DBGLN(x)
#endif

const uint8_t FC_READ_COILS        = 0x01;
const uint8_t FC_WRITE_SINGLE_COIL = 0x05;

// Result codes (same values the ESP32 version used, so the page reads them the same way)
const uint8_t RES_OK          = 0x00;   // 0x01..0x0B = Modbus exception code from the server
const uint8_t RES_UNEXPECTED  = 0xE3;   // reply did not match the request
const uint8_t RES_TIMEOUT     = 0xE4;   // no reply within RESPONSE_TIMEOUT_MS
const uint8_t RES_CONN_LOST   = 0xE5;   // connection closed before a reply
const uint8_t RES_WAITING     = 0xFF;   // internal: still waiting

EthernetServer server(80);
EthernetClient mb;    // the single Modbus client socket

// Mode and auto sequence
bool isAutomatic = true;
uint8_t autoNextState = 0;              // 0..5: R on, R off, G on, G off, B on, B off
unsigned long lastActionTime = 0;

// Coil states as read back from the server (drive the lamps)
bool coilConfirmed[3] = { false, false, false };

// Manual command queue
struct ManualCmd { uint8_t coil; bool state; };
const uint8_t MANUAL_QUEUE_SIZE = 4;
ManualCmd manualQueue[MANUAL_QUEUE_SIZE];
uint8_t mqHead = 0, mqCount = 0;

// ---------------------------------------------------------------------------
// Transaction state:  IDLE -> AWAIT_WRITE (FC 05) -> AWAIT_READ (FC 01) -> IDLE
// connect() is blocking (bounded by CONNECT_TIMEOUT_MS); waiting for replies is not.
// Every session ends with mb.stop(), whatever the outcome.
// ---------------------------------------------------------------------------
enum Phase : uint8_t { PH_IDLE, PH_AWAIT_WRITE, PH_AWAIT_READ };
Phase phase = PH_IDLE;
unsigned long phaseStart = 0;

uint8_t  curCoil = 0;
bool     curState = false;
bool     curManual = false;
bool     curWriteOk = false;
bool     curReadVal = false;
uint16_t curTid = 0;
uint32_t curLogSeq = 0;
uint16_t nextTid = 1;

uint8_t rx[16];
uint8_t rxLen = 0;

// ---------------------------------------------------------------------------
// Command log (ring buffer) and counters shown on the page
// ---------------------------------------------------------------------------
enum TxStatus : uint8_t { ST_PENDING = 0, ST_DONE = 1, ST_NOT_SENT = 2, ST_CONNECT_FAIL = 3 };

const uint8_t F_STATE = 0x01, F_MANUAL = 0x02, F_AFTER_FAILED_WRITE = 0x04;

struct LogEntry {
  uint32_t seq;
  uint32_t ms;
  uint16_t tid;       // 0 = not sent
  uint16_t rtt;
  uint8_t  fc;
  uint8_t  coil;
  uint8_t  status;
  uint8_t  result;
  int8_t   readVal;   // FC 01: -1 unknown, 0 off, 1 on
  uint8_t  flags;
};

const uint8_t LOG_SIZE = 15;
LogEntry txLog[LOG_SIZE];
uint8_t logHead = 0, logCount = 0;
uint32_t txSeq = 0;

// Summary for the "Commands sent" section (reset by Clear)
uint32_t statSent = 0, statOk = 0, statFail = 0;

// Per-coil counts for the lamp tiles (reset by Reset counts)
enum { C_W_SENT, C_W_OK, C_W_FAIL, C_R_SENT, C_R_OK, C_R_MISMATCH, C_R_FAIL, C_R_UNCHANGED, C_COUNT };
uint32_t coilCounts[3][C_COUNT];
unsigned long countsSince = 0;   // millis() of last reset, 0 = since boot

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------
void watchdogStart() {
  if (USE_WATCHDOG) _PROTECTED_WRITE(WDT.CTRLA, WDT_PERIOD_8KCLK_gc);
}
inline void watchdogKick() {
  if (USE_WATCHDOG) __asm__ __volatile__("wdr");
}

void bump(uint8_t counter) {
  if (curCoil < 3) coilCounts[curCoil][counter]++;
}

uint32_t logAdd(uint8_t fc, uint16_t tid, uint8_t status) {
  LogEntry &e = txLog[logHead];
  e.seq = ++txSeq;
  e.ms = millis();
  e.tid = tid;
  e.rtt = 0;
  e.fc = fc;
  e.coil = curCoil;
  e.status = status;
  e.result = 0;
  e.readVal = -1;
  e.flags = (curState ? F_STATE : 0) | (curManual ? F_MANUAL : 0);
  if (fc == FC_READ_COILS && !curWriteOk) e.flags |= F_AFTER_FAILED_WRITE;
  logHead = (logHead + 1) % LOG_SIZE;
  if (logCount < LOG_SIZE) logCount++;
  return e.seq;
}

LogEntry* logFind(uint32_t seq) {
  if (!seq) return nullptr;
  for (uint8_t i = 0; i < logCount; i++) {
    LogEntry &e = txLog[(logHead + LOG_SIZE - 1 - i) % LOG_SIZE];
    if (e.seq == seq) return &e;
  }
  return nullptr;   // e.g. the log was cleared while the request was in flight
}

void logComplete(uint8_t result, int8_t readVal, uint16_t rtt) {
  LogEntry* e = logFind(curLogSeq);
  if (!e) return;
  e->status = ST_DONE;
  e->result = result;
  e->readVal = readVal;
  e->rtt = rtt;
}

// ---------------------------------------------------------------------------
// Modbus TCP (hand-built frames over one EthernetClient)
// ---------------------------------------------------------------------------
bool mbConnect() {
  mb.setConnectionTimeout(CONNECT_TIMEOUT_MS);
  bool ok = mb.connect(slave_IP, MODBUS_PORT) == 1;
  watchdogKick();
  return ok;
}

// Closes the session. Always called when a session is done, so blocked or broken sessions
// never hold one of the W5100's four sockets.
void mbClose() {
  mb.stop();
  watchdogKick();
}

uint16_t requestData(uint8_t fc) {
  return (fc == FC_READ_COILS) ? 0x0001 : (curState ? 0xFF00 : 0x0000);
}

// Sends an FC 05 or FC 01 request for the current coil. Returns the transaction ID, 0 on failure.
uint16_t mbSend(uint8_t fc) {
  uint16_t tid = nextTid++;
  if (nextTid == 0) nextTid = 1;
  uint16_t data = requestData(fc);
  uint8_t f[12] = {
    (uint8_t)(tid >> 8), (uint8_t)tid,
    0x00, 0x00,                 // protocol ID
    0x00, 0x06,                 // length
    MODBUS_UNIT_ID,
    fc,
    0x00, curCoil,              // coil address
    (uint8_t)(data >> 8), (uint8_t)data
  };
  while (mb.available()) mb.read();   // drop anything stale
  rxLen = 0;
  if (mb.write(f, sizeof(f)) != sizeof(f)) return 0;
  return tid;
}

// Checks for the reply to the request in flight. Returns RES_WAITING while still waiting.
uint8_t mbPoll(uint8_t fc) {
  while (mb.available() && rxLen < sizeof(rx)) rx[rxLen++] = mb.read();

  if (rxLen >= 9) {
    uint16_t len = ((uint16_t)rx[4] << 8) | rx[5];
    uint8_t total = 6 + len;
    if (len < 3 || total > sizeof(rx)) return RES_UNEXPECTED;
    if (rxLen >= total) {
      if ((((uint16_t)rx[0] << 8) | rx[1]) != curTid) return RES_UNEXPECTED;
      if (rx[7] == (fc | 0x80)) return rx[8];            // Modbus exception code
      if (rx[7] != fc) return RES_UNEXPECTED;
      if (fc == FC_WRITE_SINGLE_COIL) {                    // reply must echo address and value
        uint16_t data = requestData(fc);
        if (total < 12 || rx[8] != 0x00 || rx[9] != curCoil ||
            rx[10] != (uint8_t)(data >> 8) || rx[11] != (uint8_t)data) return RES_UNEXPECTED;
        return RES_OK;
      }
      if (total < 10 || rx[8] < 1) return RES_UNEXPECTED;  // FC 01: byte count, then coil bits
      curReadVal = rx[9] & 0x01;
      return RES_OK;
    }
  }
  if (!mb.connected() && !mb.available()) return RES_CONN_LOST;
  if (millis() - phaseStart >= RESPONSE_TIMEOUT_MS) return RES_TIMEOUT;
  return RES_WAITING;
}

void printResult(const __FlashStringHelper* what, uint8_t res) {
  DBG(F("Modbus RX <- TID ")); DBG(curTid); DBG(' '); DBG(what);
  if (res == RES_OK) DBGLN(F(" ok"));
  else { DBG(F(" failed, code 0x")); DBGLN(String(res, HEX)); }
}

// Sends a request on the open session and moves to the matching wait phase
void beginRequest(uint8_t fc) {
  curTid = mbSend(fc);
  curLogSeq = logAdd(fc, curTid, curTid ? ST_PENDING : ST_NOT_SENT);
  bool isWrite = (fc == FC_WRITE_SINGLE_COIL);

  DBG(F("Modbus TX -> ")); DBG(isWrite ? F("FC05 write coil ") : F("FC01 read coil "));
  DBG(curCoil); DBG(isWrite ? (curState ? F(" = 1") : F(" = 0")) : F("")); DBG(F(" TID ")); DBGLN(curTid);

  if (!curTid) {
    statFail++;
    bump(isWrite ? C_W_FAIL : C_R_FAIL);
    mbClose();
    phase = PH_IDLE;
    return;
  }
  statSent++;
  bump(isWrite ? C_W_SENT : C_R_SENT);
  if (isWrite && !curManual) autoNextState = (autoNextState + 1) % 6;
  phaseStart = millis();
  phase = isWrite ? PH_AWAIT_WRITE : PH_AWAIT_READ;
}

void startTransaction(uint8_t coil, bool state, bool manual) {
  curCoil = coil;
  curState = state;
  curManual = manual;
  curWriteOk = false;
  curLogSeq = 0;

  if (!mbConnect()) {
    DBGLN(F("Modbus connect failed"));
    logAdd(FC_WRITE_SINGLE_COIL, 0, ST_CONNECT_FAIL);
    statFail++;
    bump(C_W_FAIL);
    mbClose();
    return;
  }
  beginRequest(FC_WRITE_SINGLE_COIL);
}

void startReadBack() {
  if (READBACK_SEPARATE_SESSION) {
    mbClose();                      // end the write session first
    if (!mbConnect()) {
      DBGLN(F("Read-back connect failed"));
      logAdd(FC_READ_COILS, 0, ST_CONNECT_FAIL);
      statFail++;
      bump(C_R_FAIL);
      mbClose();
      phase = PH_IDLE;
      return;
    }
  } else if (!mb.connected()) {
    DBGLN(F("Connection already closed, read-back skipped"));
    mbClose();
    phase = PH_IDLE;
    return;
  }
  beginRequest(FC_READ_COILS);
}

void serviceTransaction() {
  if (phase == PH_IDLE) return;
  bool isWrite = (phase == PH_AWAIT_WRITE);
  uint8_t res = mbPoll(isWrite ? FC_WRITE_SINGLE_COIL : FC_READ_COILS);
  if (res == RES_WAITING) return;
  uint16_t rtt = (uint16_t)min(millis() - phaseStart, 65535UL);

  if (isWrite) {
    logComplete(res, -1, rtt);
    printResult(F("write"), res);
    if (res == RES_OK) { statOk++; bump(C_W_OK); curWriteOk = true; }
    else               { statFail++; bump(C_W_FAIL); }
    // Read the coil back whatever the write outcome: after a blocked write
    // the read shows the coil's real (unchanged) state.
    startReadBack();
    return;
  }

  if (res == RES_OK) {
    logComplete(res, curReadVal ? 1 : 0, rtt);
    if (curCoil < 3) coilConfirmed[curCoil] = curReadVal;
    if (!curWriteOk)                 { statOk++;   bump(C_R_UNCHANGED); }   // write blocked, coil kept its state
    else if (curReadVal == curState) { statOk++;   bump(C_R_OK); }
    else                             { statFail++; bump(C_R_MISMATCH); }
  } else {
    logComplete(res, -1, rtt);
    statFail++;
    bump(C_R_FAIL);
  }
  printResult(F("read-back"), res);
  mbClose();
  phase = PH_IDLE;
}

// ---------------------------------------------------------------------------
// HTTP server
// ---------------------------------------------------------------------------
// Collects output into small chunks so the W5100 sends a few full packets instead of many tiny ones
class ChunkedOut : public Print {
 public:
  explicit ChunkedOut(Client &c) : cl(c), n(0) {}
  size_t write(uint8_t b) override {
    buf[n++] = b;
    if (n == sizeof(buf)) send();
    return 1;
  }
  void send() {
    if (n) { cl.write(buf, n); n = 0; watchdogKick(); }
  }
 private:
  Client &cl;
  uint8_t buf[64];
  uint8_t n;
};

void sendStatus(EthernetClient &c, const __FlashStringHelper* status) {
  c.print(F("HTTP/1.1 ")); c.print(status);
  c.print(F("\r\nCache-Control: no-store\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"));
}

void sendPage(EthernetClient &c) {
  c.print(F("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Encoding: gzip\r\n"
            "Cache-Control: no-cache\r\nConnection: close\r\nContent-Length: "));
  c.print(PAGE_GZ_LEN);
  c.print(F("\r\n\r\n"));
  uint8_t buf[64];
  for (uint16_t i = 0; i < PAGE_GZ_LEN; i += sizeof(buf)) {
    uint16_t n = min((uint16_t)sizeof(buf), (uint16_t)(PAGE_GZ_LEN - i));
    memcpy_P(buf, PAGE_GZ + i, n);
    c.write(buf, n);
    watchdogKick();
  }
}

void sendLog(EthernetClient &c) {
  c.print(F("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n"));
  ChunkedOut o(c);
  o.print(F("{\"mode\":\"")); o.print(isAutomatic ? F("auto") : F("manual"));
  o.print(F("\",\"ip\":\"")); o.print(Ethernet.localIP());
  o.print(F("\",\"target\":\"")); o.print(slave_IP); o.print(':'); o.print(MODBUS_PORT);
  o.print(F("\",\"unit\":")); o.print(MODBUS_UNIT_ID);
  o.print(F(",\"ct\":")); o.print(CONNECT_TIMEOUT_MS);
  o.print(F(",\"rto\":")); o.print(RESPONSE_TIMEOUT_MS);
  o.print(F(",\"seq\":")); o.print(txSeq);
  o.print(F(",\"busy\":")); o.print(phase != PH_IDLE ? 1 : 0);
  o.print(F(",\"q\":")); o.print(mqCount);
  o.print(F(",\"up\":")); o.print(millis());
  o.print(F(",\"since\":")); o.print(countsSince);
  o.print(F(",\"stats\":[")); o.print(statSent); o.print(','); o.print(statOk); o.print(','); o.print(statFail);
  o.print(F("],\"lamps\":[")); o.print(coilConfirmed[0]); o.print(','); o.print(coilConfirmed[1]); o.print(','); o.print(coilConfirmed[2]);
  o.print(F("],\"cc\":["));
  for (uint8_t i = 0; i < 3; i++) {
    if (i) o.print(',');
    o.print('[');
    for (uint8_t k = 0; k < C_COUNT; k++) { if (k) o.print(','); o.print(coilCounts[i][k]); }
    o.print(']');
  }
  o.print(F("],\"e\":["));
  for (uint8_t i = 0; i < logCount; i++) {          // newest first
    const LogEntry &e = txLog[(logHead + LOG_SIZE - 1 - i) % LOG_SIZE];
    if (i) o.print(',');
    o.print(F("{\"s\":")); o.print(e.seq);
    o.print(F(",\"m\":")); o.print(e.ms);
    o.print(F(",\"t\":")); o.print(e.tid);
    o.print(F(",\"f\":")); o.print(e.fc);
    o.print(F(",\"c\":")); o.print(e.coil);
    o.print(F(",\"o\":")); o.print((e.flags & F_STATE) ? 1 : 0);
    o.print(F(",\"a\":")); o.print((e.flags & F_MANUAL) ? 1 : 0);
    o.print(F(",\"w\":")); o.print((e.flags & F_AFTER_FAILED_WRITE) ? 1 : 0);
    o.print(F(",\"st\":")); o.print(e.status);
    o.print(F(",\"r\":")); o.print(e.result);
    o.print(F(",\"v\":")); o.print(e.readVal);
    o.print(F(",\"rt\":")); o.print(e.rtt);
    o.print('}');
  }
  o.print(F("]}"));
  o.send();
}

bool pathIs(const char* path, const char* route) {   // route given with PSTR()
  size_t n = strlen_P(route);
  return strncmp_P(path, route, n) == 0 && (path[n] == '\0' || path[n] == '?');
}

void handleHttp() {
  EthernetClient c = server.available();
  if (!c) return;
  c.setConnectionTimeout(250);

  // Request line, e.g. "GET /toggle?color=red&state=on HTTP/1.1"
  char line[72];
  uint8_t n = 0, lineLen = 0;
  bool firstLine = true, headersDone = false;
  unsigned long t0 = millis();
  while (!headersDone && millis() - t0 < 300) {
    if (!c.available()) { if (!c.connected()) break; continue; }
    char ch = c.read();
    if (ch == '\r') continue;
    if (ch == '\n') {
      if (firstLine) firstLine = false;
      else if (lineLen == 0) headersDone = true;   // blank line ends the headers
      lineLen = 0;
      continue;
    }
    lineLen++;
    if (firstLine && n < sizeof(line) - 1) line[n++] = ch;
  }
  line[n] = '\0';

  // Split out the path
  char* path = strchr(line, ' ');
  if (!path) { c.stop(); return; }
  path++;
  char* end = strchr(path, ' ');
  if (end) *end = '\0';

  if (pathIs(path, PSTR("/")) || pathIs(path, PSTR("/index.html"))) {
    sendPage(c);
  } else if (pathIs(path, PSTR("/log"))) {
    sendLog(c);
  } else if (pathIs(path, PSTR("/setmode"))) {
    if (strstr(path, "mode=auto")) {
      isAutomatic = true;
      autoNextState = 0;
      mqHead = mqCount = 0;        // drop manual presses not yet sent
    } else if (strstr(path, "mode=manual")) {
      isAutomatic = false;
    }
    sendStatus(c, F("204 No Content"));
  } else if (pathIs(path, PSTR("/toggle"))) {
    int8_t coil = -1;
    if (strstr(path, "color=red"))   coil = target_RED_Coil;
    if (strstr(path, "color=green")) coil = target_GREEN_Coil;
    if (strstr(path, "color=blue"))  coil = target_BLUE_Coil;
    bool on = strstr(path, "state=on") != nullptr;
    if (!isAutomatic && coil >= 0) {
      if (mqCount < MANUAL_QUEUE_SIZE) {
        ManualCmd &m = manualQueue[(mqHead + mqCount) % MANUAL_QUEUE_SIZE];
        m.coil = coil;
        m.state = on;
        mqCount++;
      } else {
        DBGLN(F("Manual queue full, press ignored"));
      }
    }
    sendStatus(c, F("204 No Content"));
  } else if (pathIs(path, PSTR("/clearlog"))) {
    logHead = logCount = 0;
    statSent = statOk = statFail = 0;
    sendStatus(c, F("204 No Content"));
  } else if (pathIs(path, PSTR("/resettotals"))) {
    memset(coilCounts, 0, sizeof(coilCounts));
    countsSince = millis();
    if (countsSince == 0) countsSince = 1;
    sendStatus(c, F("204 No Content"));
  } else {
    sendStatus(c, F("404 Not Found"));
  }
  c.stop();     // Connection: close, frees the socket right away
}

// ---------------------------------------------------------------------------
void setup() {
#if DEBUG_SERIAL
  Serial.begin(115200);
  delay(300);
  Serial.println();
  Serial.println(F("--- UNO WiFi Rev2 + W5100 Modbus TCP client ---"));
#endif

  // Keep the shield's SD card off the shared SPI bus
  pinMode(SD_CS_PIN, OUTPUT);
  digitalWrite(SD_CS_PIN, HIGH);

  Ethernet.init(W5100_CS_PIN);
  Ethernet.begin(mac, local_IP, primaryDNS, gateway, subnet);
  // Short retransmission settings so a dropped SYN or reply cannot stall for seconds
  Ethernet.setRetransmissionTimeout(100);   // ms
  Ethernet.setRetransmissionCount(4);

  if (Ethernet.hardwareStatus() == EthernetNoHardware) {
    DBGLN(F("Ethernet shield not found. Check that it is seated and uses D10 for chip select."));
  } else {
    DBG(F("W5100 ready, IP ")); DBGLN(Ethernet.localIP());
  }

  server.begin();
  DBGLN(F("Web server on port 80"));
  watchdogStart();
}

void loop() {
  watchdogKick();
  handleHttp();
  serviceTransaction();

  if (phase == PH_IDLE) {
    if (isAutomatic) {
      if (millis() - lastActionTime >= AUTO_INTERVAL_MS) {
        lastActionTime = millis();
        // Sequence: R on, R off, G on, G off, B on, B off
        startTransaction(autoNextState / 2, (autoNextState % 2) == 0, false);
      }
    } else if (mqCount > 0) {
      ManualCmd m = manualQueue[mqHead];
      mqHead = (mqHead + 1) % MANUAL_QUEUE_SIZE;
      mqCount--;
      startTransaction(m.coil, m.state, true);
    }
  }
}
