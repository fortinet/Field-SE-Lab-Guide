/*
  Modbus TCP server (PLC) for the Arduino UNO WiFi Rev2 (ATmega4809) with a W5100 Ethernet shield.

  Port of the ESP32-S3-ETH server sketch: three coils (0 = red, 1 = green, 2 = blue) drive three
  LED outputs. Pairs with the UNO / ESP32 client sketches (client 192.168.1.120 -> server 192.168.1.110).

  Modbus functions handled:
    FC 01  Read Coils
    FC 05  Write Single Coil         (value must be 0xFF00 or 0x0000)
    FC 15  Write Multiple Coils
    FC 02, 03, 04, 06, 16            -> exception 02 (illegal data address: nothing registered there)
    anything else                    -> exception 01 (illegal function)

  Board:      Arduino UNO WiFi Rev2 ("Arduino megaAVR Boards" core)
              Tools > Registers emulation: None (ATMEGA4809)
  Library:    Ethernet (Arduino). WiFiNINA only if USE_NINA_RGB_LED is enabled.
  Shield:     W5100 Ethernet shield (chip select D10, SD card chip select D4)

  LED wiring: each output pin -> 220 ohm resistor -> LED anode, LED cathode -> GND (HIGH = on).
*/

// Set to 1 to also show the coils on the board's built-in RGB LED (driven through the NINA module,
// needs the WiFiNINA library). The external LED pins below are driven either way.
#define USE_NINA_RGB_LED 0

#include <SPI.h>
#include <Ethernet.h>
#include <avr/wdt.h> // <-- Add this line

#if USE_NINA_RGB_LED
  #include <WiFiNINA.h>
  #include <utility/wifi_drv.h>
#endif

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------
// The W5100 shield has no MAC address of its own. This is a locally administered address;
// use the one printed on the shield's sticker instead if it has one. Must differ from the client's.
byte mac[] = { 0x02, 0x00, 0x00, 0x01, 0x01, 0x6E };

IPAddress local_IP(192, 168, 1, 10);     // matches slave_IP in the client sketches
IPAddress gateway(192, 168, 1, 1);
IPAddress subnet(255, 255, 255, 0);
IPAddress primaryDNS(8, 8, 8, 8);

const uint16_t MODBUS_PORT = 502;

// Coils and the LED output for each
const uint16_t target_RED_Coil   = 0x00;
const uint16_t target_GREEN_Coil = 0x01;
const uint16_t target_BLUE_Coil  = 0x02;

#define TARGET_RED_LED_PIN    5
#define TARGET_GREEN_LED_PIN  6
#define TARGET_BLUE_LED_PIN   7

// A client connection with no traffic for this long is closed. The W5100 has only four sockets;
// without this, sessions left half-open (for example when a firewall drops a session mid-stream)
// would eventually use them all up.
const unsigned long IDLE_TIMEOUT_MS = 10000;

// Hardware watchdog (about 8 s). Resets the board if the sketch ever stalls.
const bool USE_WATCHDOG = true;

// Serial debug output at 115200 baud (set to 0 to save flash)
#define DEBUG_SERIAL 1

// Shield / board pins
const uint8_t W5100_CS_PIN = 10;
const uint8_t SD_CS_PIN    = 4;

// ---------------------------------------------------------------------------
#if DEBUG_SERIAL
  #define DBG(x)   Serial.print(x)
  #define DBGLN(x) Serial.println(x)
#else
  #define DBG(x)
  #define DBGLN(x)
#endif

const uint8_t COIL_COUNT = 3;
const uint8_t ledPins[COIL_COUNT] = { TARGET_RED_LED_PIN, TARGET_GREEN_LED_PIN, TARGET_BLUE_LED_PIN };
#if USE_NINA_RGB_LED
const uint8_t ninaLedPins[COIL_COUNT] = { 26, 25, 27 };   // NINA GPIOs for the RGB LED: red, green, blue
#endif

bool coils[COIL_COUNT]   = { false, false, false };       // Modbus coil table
bool outputs[COIL_COUNT] = { false, false, false };       // what the LED pins currently show

const uint8_t EX_ILLEGAL_FUNCTION = 0x01;
const uint8_t EX_ILLEGAL_ADDRESS  = 0x02;
const uint8_t EX_ILLEGAL_VALUE    = 0x03;

EthernetServer mbServer(MODBUS_PORT);

// Per-socket receive state (the W5100 has four sockets)
const uint8_t SOCKETS = 4;
const uint8_t RX_BUF  = 32;          // enough for any request on three coils
struct Conn {
  uint16_t remotePort;               // identifies the connection currently on this socket
  uint16_t got;                      // bytes received of the current frame
  uint16_t need;                     // full frame length once the MBAP header is in, 0 = unknown
  unsigned long lastActivity;
  uint8_t buf[RX_BUF];
};
Conn conns[SOCKETS];

unsigned long lastIdleCheck = 0;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
void watchdogStart() {
  if (USE_WATCHDOG) {
    // 8192 cycles at ~1.024 kHz = ~8 seconds
    wdt_enable(WDT_PERIOD_8KCLK_gc); 
  }
}

inline void watchdogKick() {
  if (USE_WATCHDOG) {
    wdt_reset(); // Standard watchdog reset/kick function
  }
}

void resetConn(Conn &k, uint16_t remotePort) {
  k.remotePort = remotePort;
  k.got = 0;
  k.need = 0;
  k.lastActivity = millis();
}

void printHex2(uint8_t v) {
  if (v < 0x10) DBG('0');
  DBG(String(v, HEX));
}

// Updates the LED pins when a coil changes
void applyOutputs() {
  for (uint8_t i = 0; i < COIL_COUNT; i++) {
    if (coils[i] == outputs[i]) continue;
    outputs[i] = coils[i];
    digitalWrite(ledPins[i], outputs[i] ? HIGH : LOW);
#if USE_NINA_RGB_LED
    WiFiDrv::digitalWrite(ninaLedPins[i], outputs[i] ? HIGH : LOW);
#endif
    DBG(F("Modbus RX -> Coil 0x")); printHex2(i);
    DBG(outputs[i] ? F(" changed to ON.  Pin D") : F(" changed to OFF. Pin D"));
    DBG(ledPins[i]); DBGLN(outputs[i] ? F(" set to 1") : F(" set to 0"));
  }
}

// ---------------------------------------------------------------------------
// Modbus request handling
// ---------------------------------------------------------------------------
// Writes an exception reply: MBAP + (function | 0x80) + exception code
void sendException(EthernetClient &c, const uint8_t* req, uint8_t code) {
  uint8_t out[9] = { req[0], req[1], 0x00, 0x00, 0x00, 0x03, req[6], (uint8_t)(req[7] | 0x80), code };
  c.write(out, sizeof(out));
  DBG(F("  -> exception 0x")); printHex2(code); DBGLN(F(" sent"));
}

// Handles one complete request frame (MBAP header + PDU) held in req[0..total-1]
void processRequest(EthernetClient &c, const uint8_t* req, uint16_t total) {
  uint8_t fc = req[7];
  uint8_t pduLen = total - 7;                   // function code + data
  uint16_t addr = (pduLen >= 3) ? (((uint16_t)req[8] << 8) | req[9]) : 0;
  uint16_t val  = (pduLen >= 5) ? (((uint16_t)req[10] << 8) | req[11]) : 0;

  DBG(F("Modbus RX <- FC")); printHex2(fc); DBG(F(" addr ")); DBG(addr);
  DBG(F(" from ")); DBG(c.remoteIP()); DBG(':'); DBGLN(c.remotePort());

  uint8_t out[RX_BUF];
  // Copy transaction ID, protocol ID and unit ID from the request
  out[0] = req[0]; out[1] = req[1]; out[2] = 0x00; out[3] = 0x00; out[6] = req[6]; out[7] = fc;
  uint8_t pduOut = 0;                           // reply PDU length after the function code

  switch (fc) {
    case 0x01: {                                // Read Coils
      if (pduLen < 5 || val < 1 || val > 2000) { sendException(c, req, EX_ILLEGAL_VALUE); return; }
      if ((uint32_t)addr + val > COIL_COUNT)   { sendException(c, req, EX_ILLEGAL_ADDRESS); return; }
      uint8_t bytes = (val + 7) / 8;
      out[8] = bytes;
      for (uint8_t b = 0; b < bytes; b++) out[9 + b] = 0;
      for (uint16_t i = 0; i < val; i++) if (coils[addr + i]) out[9 + i / 8] |= (1 << (i % 8));
      pduOut = 1 + bytes;
      break;
    }
    case 0x05: {                                // Write Single Coil
      if (pduLen < 5 || (val != 0xFF00 && val != 0x0000)) { sendException(c, req, EX_ILLEGAL_VALUE); return; }
      if (addr >= COIL_COUNT)                             { sendException(c, req, EX_ILLEGAL_ADDRESS); return; }
      coils[addr] = (val == 0xFF00);
      for (uint8_t i = 0; i < 4; i++) out[8 + i] = req[8 + i];   // reply echoes address and value
      pduOut = 4;
      break;
    }
    case 0x0F: {                                // Write Multiple Coils
      uint8_t byteCount = (pduLen >= 6) ? req[12] : 0;
      if (pduLen < 6 || val < 1 || val > 1968 || byteCount != (val + 7) / 8 || pduLen < 6 + byteCount) {
        sendException(c, req, EX_ILLEGAL_VALUE); return;
      }
      if ((uint32_t)addr + val > COIL_COUNT) { sendException(c, req, EX_ILLEGAL_ADDRESS); return; }
      for (uint16_t i = 0; i < val; i++) coils[addr + i] = (req[13 + i / 8] >> (i % 8)) & 0x01;
      for (uint8_t i = 0; i < 4; i++) out[8 + i] = req[8 + i];   // reply: address and quantity
      pduOut = 4;
      break;
    }
    case 0x02: case 0x03: case 0x04: case 0x06: case 0x10:
      // Valid functions, but no discrete inputs or registers exist on this server
      sendException(c, req, EX_ILLEGAL_ADDRESS);
      return;
    default:
      sendException(c, req, EX_ILLEGAL_FUNCTION);
      return;
  }

  uint16_t len = 2 + pduOut;                   // unit ID + function code + data
  out[4] = len >> 8;
  out[5] = len & 0xFF;
  c.write(out, 6 + len);
  applyOutputs();
}

// Reads whatever this client has sent and processes each complete frame
void serviceClient(EthernetClient &c) {
  uint8_t s = c.getSocketNumber();
  if (s >= SOCKETS) return;
  Conn &k = conns[s];
  uint16_t port = c.remotePort();
  if (port != k.remotePort) {
    resetConn(k, port);
    DBG(F("Client connected: ")); DBG(c.remoteIP()); DBG(':'); DBG(port);
    DBG(F(" (socket ")); DBG(s); DBGLN(')');
  }
  k.lastActivity = millis();

  while (c.available()) {
    uint8_t b = c.read();
    if (k.got < RX_BUF) k.buf[k.got] = b;
    k.got++;

    if (k.got == 6) {                           // MBAP length field is in
      uint16_t len = ((uint16_t)k.buf[4] << 8) | k.buf[5];
      if (len < 2 || len > 254) {               // not Modbus TCP: drop the connection
        DBGLN(F("Bad MBAP length, closing connection"));
        c.stop();
        resetConn(k, 0);
        return;
      }
      k.need = 6 + len;
    }
    if (k.need && k.got == k.need) {
      bool protocolOk = (k.buf[2] == 0 && k.buf[3] == 0);
      if (!protocolOk) {
        DBGLN(F("Protocol ID is not 0, request ignored"));
      } else if (k.need > RX_BUF) {
        sendException(c, k.buf, EX_ILLEGAL_VALUE);   // longer than any valid request for three coils
      } else {
        processRequest(c, k.buf, k.need);
      }
      k.got = 0;
      k.need = 0;
    }
  }
}

// Closes client sockets that have gone quiet, so they cannot pile up on the W5100
void closeIdleSockets() {
  for (uint8_t i = 0; i < SOCKETS; i++) {
    EthernetClient t(i);
    uint8_t st = t.status();
    if (st != 0x17 && st != 0x1C) continue;     // only ESTABLISHED or CLOSE_WAIT client sockets
    uint16_t port = t.remotePort();
    if (port != conns[i].remotePort) {          // a connection we have not seen data from yet
      resetConn(conns[i], port);
      continue;
    }
    if (millis() - conns[i].lastActivity >= IDLE_TIMEOUT_MS) {
      DBG(F("Closing idle connection on socket ")); DBGLN(i);
      t.setConnectionTimeout(200);
      t.stop();
      resetConn(conns[i], 0);
      watchdogKick();
    }
  }
}

// ---------------------------------------------------------------------------
void setup() {
#if DEBUG_SERIAL
  Serial.begin(115200);
  delay(300);
  Serial.println();
  Serial.println(F("--- UNO WiFi Rev2 + W5100 (Server Mode) ---"));
#endif

  for (uint8_t i = 0; i < COIL_COUNT; i++) {
    pinMode(ledPins[i], OUTPUT);
    digitalWrite(ledPins[i], LOW);
  }

  // Keep the shield's SD card off the shared SPI bus
  pinMode(SD_CS_PIN, OUTPUT);
  digitalWrite(SD_CS_PIN, HIGH);

#if USE_NINA_RGB_LED
  WiFiDrv::wifiDriverInit();
  for (uint8_t i = 0; i < COIL_COUNT; i++) {
    WiFiDrv::pinMode(ninaLedPins[i], OUTPUT);
    WiFiDrv::digitalWrite(ninaLedPins[i], LOW);
  }
#elif defined(SPIWIFI_SS)
  // The Wi-Fi module shares the SPI bus with the W5100: keep it deselected
  pinMode(SPIWIFI_SS, OUTPUT);
  digitalWrite(SPIWIFI_SS, HIGH);
#endif

  Ethernet.init(W5100_CS_PIN);
  Ethernet.begin(mac, local_IP, primaryDNS, gateway, subnet);

  if (Ethernet.hardwareStatus() == EthernetNoHardware) {
    DBGLN(F("Ethernet shield not found. Check that it is seated and uses D10 for chip select."));
  } else {
    DBG(F("W5100 ready, IP ")); DBGLN(Ethernet.localIP());
  }

  for (uint8_t i = 0; i < SOCKETS; i++) resetConn(conns[i], 0);
  mbServer.begin();
  DBG(F("Modbus server listening on port ")); DBGLN(MODBUS_PORT);
  watchdogStart();
}

void loop() {
  watchdogKick();

  EthernetClient c = mbServer.available();     // a client with data waiting, if any
  if (c) serviceClient(c);

  if (millis() - lastIdleCheck >= 500) {
    lastIdleCheck = millis();
    closeIdleSockets();
  }
}
